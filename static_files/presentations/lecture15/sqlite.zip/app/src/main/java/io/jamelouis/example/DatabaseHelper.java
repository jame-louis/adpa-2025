package io.jamelouis.example;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private final Context context;
    private static final String DATABASE_NAME = "demo.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS myTable");
        onCreate(db);
    }

    /**
     * Returns a simple object that holds id + name, or null if not found.
     */
    public UserRow query(String name) {
        /*
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT id, name FROM users WHERE name = ? LIMIT 1";
        Cursor c = db.rawQuery(sql, new String[]{name});
        try {
            if (c.moveToFirst()) {                 // at least one row
                long   id   = c.getLong(0);        // column 0 = id
                String n    = c.getString(1);      // column 1 = name
                return new UserRow(id, n);
            }
            return null;                           // no match
        } finally {
            c.close();                             // always release cursor
        }
         */
        return null;
    }

    public void add(String name) {
        /*
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO users (name) VALUES (?)", new Object[]{name});
         */
    }

    /* tiny POJO to carry the result */
    public static class UserRow {
        public final long id;
        public final String name;
        public UserRow(long id, String name) {
            this.id = id;
            this.name = name;
        }
    }
}
