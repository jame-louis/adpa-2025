package io.jamelouis.example;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        if(getIntent() != null) {
            String name = getIntent().getStringExtra("name");
            TextView textView = findViewById(R.id.name_welcome);
            textView.setText(name);
        }
    }
}