package io.jamelouis.example;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void onClickLogin(View v) {
        /*
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        EditText editText = findViewById(R.id.name_edit_text_login);
        String name = editText.getText().toString();
        DatabaseHelper.UserRow userRow = databaseHelper.query(name);
        if(userRow == null) {
            Toast.makeText(this, "未注册账户", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "注册账户 " + userRow.id + " " + userRow.name, Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this, WelcomeActivity.class);
            i.putExtra("name", userRow.id + " " + userRow.name);
            startActivity(i);
        }
         */
    }
}