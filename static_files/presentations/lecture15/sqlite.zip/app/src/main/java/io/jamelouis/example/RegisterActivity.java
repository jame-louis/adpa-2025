package io.jamelouis.example;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }

    public void  onClickRegister(View v) {
        EditText editText = findViewById(R.id.name_edit_text_register);
        String name = editText.getText().toString();
        Toast.makeText(this, name, Toast.LENGTH_SHORT).show();
        /*
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        if(databaseHelper.query(name) != null) {
            Toast.makeText(this, "该名称已被注册"+name, Toast.LENGTH_LONG).show();
        } else {
            databaseHelper.add(name);
            Toast.makeText(this, "成功添加账户"+name, Toast.LENGTH_SHORT).show();
        }
         */
    }
}