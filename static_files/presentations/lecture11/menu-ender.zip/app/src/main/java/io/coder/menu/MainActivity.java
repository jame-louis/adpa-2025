package io.coder.menu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // todo: register context menu
        TextView t = findViewById(R.id.msg);
        registerForContextMenu(t);
    }

    /* option menu */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // todo: create options menu
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // todo: add click event for options menu items
        return onMenuItemSelected(item);
    }


    /* context menu */
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        // todo: create context menu
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        // todo: add click event for context menu items
        return onMenuItemSelected(item);
    }


    /* popup menu */
    public void onClickPoppuMenu(View v) {
        // todo: create popup menu and add click event for popup menu items
        PopupMenu popup = new PopupMenu(this, v);
        popup.getMenuInflater().inflate(R.menu.main_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(this::onMenuItemSelected);
        popup.show();
    }

    /* help function */
    private boolean onMenuItemSelected(@NonNull MenuItem item) {
        // todo: set text by current menu item's title.
        String value = "Hello, world";
        switch (item.getItemId()) {
            case R.id.new_chat:
                value = item.getTitle().toString();
                break;
            case R.id.add_contacts:
                value = item.getTitle().toString();
                break;
            default:
                return false;
        }
        TextView t = findViewById(R.id.msg);
        t.setText(value);
        return true;
    }



}