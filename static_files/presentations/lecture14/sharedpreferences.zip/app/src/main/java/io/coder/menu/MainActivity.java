package io.coder.menu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNickname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Log.d("402", "onCreate");
        setContentView(R.layout.activity_main);

        // editTextNickname = findViewById(R.id.editTextNickname);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Log.d("402", "onResume");
        /*
        // Retrieving stored data from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("UserPreferences", MODE_PRIVATE);
        String savedName = sharedPreferences.getString("nick_name", "");

        // Populating EditText fields with stored data
        editTextNickname.setText(savedName);
         */
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Log.d("402", "onPause");
        /*
        // Storing data in SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("UserPreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Retrieving user input and saving it
        editor.putString("nick_name", editTextNickname.getText().toString());

        editor.apply();
         */
    }
}